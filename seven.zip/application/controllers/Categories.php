<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Categories extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Categories_model');
        
    }


    public function index(){
        
        $categories = $this->Categories_model->get_all();

        $data = array(
            'data_kategori' => $categories


        );
        $this->load->view('template/header');
        $this->load->view('template/menu');
        $this->load->view('categories', $data);
    
}
 
   
}
   