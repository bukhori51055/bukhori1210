<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Barang extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model');
        
    }


    public function index(){
        
        $barang = $this->Barang_model->get_all();

        $data = array(
            'data_barang' => $barang
            

        );
        $this->load->view('template/header');
        $this->load->view('template/menu');
        $this->load->view('barang', $data);
    
}
 
   
}
   