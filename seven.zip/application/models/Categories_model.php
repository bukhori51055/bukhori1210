<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Categories_model extends CI_Model
{

    public $table = 'product_categories';
    public $id = 'id';
    public $order = 'ASC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    public function duatable() {
      $this->db->select('*');
      $this->db->from('products');
      $this->db->join('product_categories','product_categories.id=products.id');
      $query = $this->db->get();
      return $query->result();
  }   

}


