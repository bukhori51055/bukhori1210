

    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="page-head-line">Data Kategori</h4>

                </div>
              
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert">
                       <div class="panel panel-default">

                        <div class="panel-heading">
                            
                     

                        </div>

     <div class="panel-body">

        <div class="table-responsive">
        <table id="table_mitra" class="table table-striped table-bordered table-hover">
          <thead>
            <tr>
            
             <th>ID</th>
             <th>Name</th>
             <th>Category</th>
            
            </tr>
          </thead>
                      

            <tbody>
            <?php
           
            foreach ($data_kategori as $categories)
            {
                ?>
                <tr>
            
            <td><?php echo $categories->id ?></td>
            <td><?php echo $categories->name ?></td>
            
            
            <td><?php echo $categories->created_date ?></td>
             
            
            
            </tr>
                <?php
            }
            ?>
            </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                  
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
   



    <?php $this->load->view('template/footer'); ?>
   

