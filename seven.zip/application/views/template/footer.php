<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2018 Imam Bukhori <a href="<?php echo base_url(); ?> " target="_blank"></a>
                </div>

            </div>
        </div>
    </footer>

   
    
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo base_url('assets/js/bootstrap.js'); ?>"></script>

</body>
</html>