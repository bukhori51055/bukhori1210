<style>
.dropbtn {
    background-color: #3F3D3D;
    color: white;
    padding: 6px;
    font-size: 16px;
    border: none;
    cursor: pointer;

}

.dropdown {
    position: all;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F3D3D;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #CB7B7B}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #F08080;
}
</style>
<!-- AWAL MENU -->
    <section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a  href="<?php echo base_url('barang') ?>">Product</a></li>
                            <li><a href="<?php echo base_url('categories') ?>">Category</a></li>
                            
                            
                            
                         </div>
                        </div>
                            
                            

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- MENU SECTION END-->
    <!-- TERAKHIR MENU-->